Creates and runs a node that takes joystick information 
from an external controller and posts it to the eduMIP robot

Created by Andrew Dykman for EN.530.707 at JHU

Notes:

Joy Axes are 1 and 0, instead of 1 and 2 as initially instructed (as that is my controllers set-up)

I have a VM, and therefore my controller is mapped to dev/input/js2, in case that causes any issues
